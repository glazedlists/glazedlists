import java.sql.*;
import java.util.*;
import com.odellengineeringltd.glazedlists.query.*;

class ProgrammingLanguageQuery implements Query {

    String jdbcDriverClassname;
    String jdbcUri;
    String jdbcUsername;
    String jdbcPassword;
    
    public ProgrammingLanguageQuery(String[] jdbcParameters) {
        jdbcDriverClassname = jdbcParameters[0];
        jdbcUri = jdbcParameters[1];
        jdbcUsername = jdbcParameters[2];
        jdbcPassword = jdbcParameters[3];
    }
    
    public String getName() {
        return "Programming Languages";
    }

    public SortedSet doQuery() throws InterruptedException {

        SortedSet results = new TreeSet();

        try {
            Class.forName(jdbcDriverClassname);
            Connection connection = DriverManager.getConnection(jdbcUri, jdbcUsername, jdbcPassword);
            PreparedStatement getAll = connection.prepareStatement("SELECT pl_name, pl_year, pl_description, pl_oop, pl_vm FROM programming_languages");
            ResultSet resultSet = getAll.executeQuery();

            while(resultSet.next()) {
                String name = resultSet.getString("pl_name");
                String year = resultSet.getString("pl_year");
                String description = resultSet.getString("pl_description");
                boolean oop = resultSet.getString("pl_oop").equalsIgnoreCase("Y");
                boolean vm = resultSet.getString("pl_vm").equalsIgnoreCase("Y");
                
                results.add(new ProgrammingLanguage(name, year, description, oop, vm));
            }
            connection.close();
            
            return results;

        } catch(ClassNotFoundException e) {
            e.printStackTrace();
            return results;
        } catch(SQLException e) {
            e.printStackTrace();
            return results;
        }
        
    }
    
    public boolean matchesObject(Comparable object) {
        return (object instanceof ProgrammingLanguage);
    }
}    

