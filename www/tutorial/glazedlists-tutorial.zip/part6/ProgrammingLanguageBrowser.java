import com.odellengineeringltd.glazedlists.*;
import com.odellengineeringltd.glazedlists.jtable.*;
import com.odellengineeringltd.glazedlists.query.*;
import javax.swing.*;
import java.awt.*;

public class ProgrammingLanguageBrowser {

    DynamicQueryList dynamicLanguages;
    SortedList sortedLanguages;
    CaseInsensitiveFilterList filteredLanguages;
    ProgrammingLanguageFilter customFilteredLanguages;

    ProgrammingLanguageNameComparator sortByName = new ProgrammingLanguageNameComparator();
    ProgrammingLanguageYearComparator sortByYear = new ProgrammingLanguageYearComparator();

    public ProgrammingLanguageBrowser(String[] jdbcParameters) {
        dynamicLanguages = new DynamicQueryList(1000*30);
        dynamicLanguages.setQuery(new ProgrammingLanguageQuery(jdbcParameters));
        
        sortedLanguages = new SortedList(dynamicLanguages, sortByName);
        filteredLanguages = new CaseInsensitiveFilterList(sortedLanguages);
        customFilteredLanguages = new ProgrammingLanguageFilter(filteredLanguages);
    }
    
    public void display() {
        ListTable listTable = new ListTable(customFilteredLanguages, new ProgrammingLanguageTableCell());
        
        TableComparatorSelector sortSelect = new TableComparatorSelector(listTable, sortedLanguages);
        sortSelect.addComparator(0, "by name", sortByName);
        sortSelect.addComparator(0, "by year", sortByYear);
        
        JFrame frame = new JFrame("Programming Languages");
        frame.getContentPane().setLayout(new GridBagLayout());
        frame.getContentPane().add(new JLabel("Filter"), new GridBagConstraints(0, 0, 1, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(2, 2, 2, 2), 0, 0));
        frame.getContentPane().add(filteredLanguages.getFilterEdit(), new GridBagConstraints(1, 0, 1, 1, 0.0, 0.0, GridBagConstraints.CENTER, GridBagConstraints.HORIZONTAL, new Insets(2, 2, 2, 2), 0, 0));
        frame.getContentPane().add(customFilteredLanguages.getObjectOrientedCheckBox(), new GridBagConstraints(0, 1, 2, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(2, 2, 2, 2), 0, 0));
        frame.getContentPane().add(customFilteredLanguages.getVirtualMachineCheckBox(), new GridBagConstraints(0, 2, 2, 1, 0.0, 0.0, GridBagConstraints.WEST, GridBagConstraints.HORIZONTAL, new Insets(2, 2, 2, 2), 0, 0));
        frame.getContentPane().add(listTable.getTableScrollPane(), new GridBagConstraints(0, 3, 2, 1, 1.0, 1.0, GridBagConstraints.CENTER, GridBagConstraints.BOTH, new Insets(2, 2, 2, 2), 0, 0));
        frame.setSize(640, 480);
        frame.show();
    }
    
    public static void main(String[] args) {
        ProgrammingLanguageBrowser browser = new ProgrammingLanguageBrowser(args);
        browser.display();
    }
}
