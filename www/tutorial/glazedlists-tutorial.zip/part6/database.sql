CREATE TABLE programming_languages (
    pl_name VARCHAR(64),
    pl_year VARCHAR(4),
    pl_description VARCHAR(255),
    pl_oop VARCHAR(1),
    pl_vm VARCHAR(1)
);

INSERT INTO programming_languages VALUES('Java', '1995', 'Object-oriented virtual machine language by Sun Microsystems', 'Y', 'Y');
INSERT INTO programming_languages VALUES('C', '1973', 'The UNIX language originally developed for the PDP-11', 'N', 'N');
INSERT INTO programming_languages VALUES('C++', '1983', 'Object-oriented C', 'Y', 'N');
INSERT INTO programming_languages VALUES('BASIC', '1964', 'Beginner''s All Purpose Symbolic Instruction Code', 'N', 'N');
INSERT INTO programming_languages VALUES('COBOL', '1960', 'COmmon Business Oriented Language', 'N', 'N');
INSERT INTO programming_languages VALUES('Eiffel', '1987', 'Object-oriented language encouraging code simplicity', 'Y', 'N');
INSERT INTO programming_languages VALUES('Fortran', '1954', 'Formula Translation language for scientific computation', 'N', 'N');
INSERT INTO programming_languages VALUES('Lisp', '1958', 'Heavily Recursive language for AI programming', 'N', 'N');
INSERT INTO programming_languages VALUES('Perl', '1987', 'The "More than one way to do it" scripting language', 'N', 'Y');
INSERT INTO programming_languages VALUES('PHP', '1994', 'HTML-embedded scripting language', 'Y', 'N');
INSERT INTO programming_languages VALUES('Python', '1986', 'Clear syntax object-oriented programming language', 'Y', 'N');
INSERT INTO programming_languages VALUES('Ruby', '1993', 'Object-oriented scripting language', 'Y', 'N');
INSERT INTO programming_languages VALUES('Visual Basic', '1992', 'QuickBasic with a visual UI designer', 'N', 'N');

