import com.odellengineeringltd.glazedlists.*;
import com.odellengineeringltd.glazedlists.jtable.*;
import javax.swing.*;

public class ProgrammingLanguageBrowser {

    BasicEventList languages;

    public ProgrammingLanguageBrowser() {
        languages = new BasicEventList();
        languages.add(new ProgrammingLanguage("Java", "1995", "Object-oriented virtual machine language by Sun Microsystems"));
        languages.add(new ProgrammingLanguage("C", "1973", "The UNIX language originally developed for the PDP-11"));
        languages.add(new ProgrammingLanguage("C++", "1983", "Object-oriented C"));
        languages.add(new ProgrammingLanguage("BASIC", "1964", "Beginner's All Purpose Symbolic Instruction Code"));
        languages.add(new ProgrammingLanguage("COBOL", "1960", "COmmon Business Oriented Language"));
        languages.add(new ProgrammingLanguage("Eiffel", "1987", "Object-oriented language encouraging code simplicity"));
        languages.add(new ProgrammingLanguage("Fortran", "1954", "Formula Translation language for scientific computation"));
        languages.add(new ProgrammingLanguage("Lisp", "1958", "Heavily Recursive language for AI programming"));
        languages.add(new ProgrammingLanguage("Perl", "1987", "The \"More than one way to do it\" scripting language"));
        languages.add(new ProgrammingLanguage("PHP", "1994", "HTML-embedded scripting language"));
        languages.add(new ProgrammingLanguage("Python", "1986", "Clear syntax object-oriented programming language"));
        languages.add(new ProgrammingLanguage("Ruby", "1993", "Object-oriented scripting language"));
        languages.add(new ProgrammingLanguage("Visual Basic", "1992", "QuickBasic with a visual UI designer"));
    }
    
    public void display() {
        ListTable listTable = new ListTable(languages, new ProgrammingLanguageTableCell());
        JFrame frame = new JFrame("Programming Languages");
        frame.getContentPane().add(listTable.getTableScrollPane());
        frame.setSize(640, 480);
        frame.show();
    }
    
    public static void main(String[] args) {
        ProgrammingLanguageBrowser browser = new ProgrammingLanguageBrowser();
        browser.display();
    }
}
