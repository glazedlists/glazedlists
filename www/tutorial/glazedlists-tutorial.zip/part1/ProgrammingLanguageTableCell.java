import com.odellengineeringltd.glazedlists.jtable.*;
import javax.swing.*;

public class ProgrammingLanguageTableCell implements TableFormat {

    public int getFieldCount() {
        return 2; 
    }

    public String getFieldName(int column) { 
        if(column == 0) return "Name";
        else return "Year";
    }
    
    public Object getFieldValue(Object baseObject, int column) {
        ProgrammingLanguage lang = (ProgrammingLanguage)baseObject;
        
        if(column == 0) return lang.getName();
        else return lang.getYear();
    }
    
    public void configureTable(JTable table) {
        // no configuration necessary, yet
    }

}
