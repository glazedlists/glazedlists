import com.odellengineeringltd.glazedlists.*;

class ProgrammingLanguage implements Filterable {
    private String name;
    private String year;
    private String description;
    
    public ProgrammingLanguage(String name, String year, String description) {
        this.name = name;
        this.year = year;
        this.description = description;
    }

    public String[] getFilterStrings() {
        return new String[] { name, year, description };
    }
    
    public String getName() {
        return name;
    }
    
    public String getYear() {
        return year;
    }
    
    public String getDescription() {
        return description;
    }
}

